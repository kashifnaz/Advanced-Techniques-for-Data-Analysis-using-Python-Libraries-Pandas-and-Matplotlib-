### Hello, welcome to another lesson on python and the data science libraries ( Numpy,Pandas and Matplotlib). This is another dummy dataset that i worked on as i learned and grow on this career path. I want you to connect deeply with these dataset and feel encouraged about what you're doing. We all do it a little poorly until we get better.That's why i share my journey and my growth process.

### In this very dataset, the data is the same as that of the last lesson. But the approach is about using advance techniques to achieve the same task while writing lesser lines of code to achieve the task. Also, Matplotlib Library for Data Visualization will be introduced in this lesson.

### And to make it more interesting, you'll join 2 datasets together which you'll read from separate pages of this excel file which will be imported


## So fasten your seatbelts and Let's Get Started !!!

### The first step is to import the necessary libraries using standard convention. And this time you're going to import matplotlib. Then import the data and read some chunk of it

#### Notice the line of code that reads "%matplotlib inline".

#### This will ensure that everytime you write a command to plot, it'll be displayed without additional effort. Skipping this step will mean you have to type "plt.show()" everytime you make a plot.


## So, save yourself some stress  !


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
dataset = pd.read_excel("Excursion Portfolio.xls", sheet_name = 0)
dataset.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Unnamed: 1</th>
      <th>Unnamed: 2</th>
      <th>Unnamed: 3</th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
      <th>Unnamed: 9</th>
      <th>Unnamed: 10</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>S/N</td>
      <td>Name</td>
      <td>Status</td>
      <td>Amount Paid</td>
      <td>T-shirt</td>
      <td>NaN</td>
      <td>Comments</td>
    </tr>
    <tr>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Type</td>
      <td>Amount</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>6</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>Victor T. Na'Allah</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2</td>
      <td>Olajide Mattew</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>8</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3</td>
      <td>Abel Modu Timothy</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>9</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4</td>
      <td>Egwim Jones Udojuaku</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



### Check the summary description and statistics  of the Dataset to familiarize yourself with the data


```python
dataset.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 58 entries, 0 to 57
    Data columns (total 11 columns):
    Unnamed: 0     0 non-null float64
    Unnamed: 1     0 non-null float64
    Unnamed: 2     0 non-null float64
    Unnamed: 3     0 non-null float64
    Unnamed: 4     52 non-null object
    Unnamed: 5     50 non-null object
    Unnamed: 6     50 non-null object
    Unnamed: 7     51 non-null object
    Unnamed: 8     41 non-null object
    Unnamed: 9     41 non-null object
    Unnamed: 10    7 non-null object
    dtypes: float64(4), object(7)
    memory usage: 3.5+ KB



```python
dataset.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Unnamed: 1</th>
      <th>Unnamed: 2</th>
      <th>Unnamed: 3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>mean</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>std</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>min</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>25%</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>50%</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>75%</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>max</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
dataset.shape
```




    (58, 11)




```python
dataset.size
```




    638




```python
dataset.ndim
```




    2




```python
dataset.dtypes
```




    Unnamed: 0     float64
    Unnamed: 1     float64
    Unnamed: 2     float64
    Unnamed: 3     float64
    Unnamed: 4      object
    Unnamed: 5      object
    Unnamed: 6      object
    Unnamed: 7      object
    Unnamed: 8      object
    Unnamed: 9      object
    Unnamed: 10     object
    dtype: object



### Since a visual clue to the data reveals that some rows and columns contains   nan, use "dropna" to delete all rows and columns that contains "nan" across the columns and down the rows respectively


```python
dataset.dropna(how = 'all', inplace = True)
```


```python
dataset.dropna(how = "all", axis = 1, inplace = True)
```


```python
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
      <th>Unnamed: 9</th>
      <th>Unnamed: 10</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>4</td>
      <td>S/N</td>
      <td>Name</td>
      <td>Status</td>
      <td>Amount Paid</td>
      <td>T-shirt</td>
      <td>NaN</td>
      <td>Comments</td>
    </tr>
    <tr>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Type</td>
      <td>Amount</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>6</td>
      <td>1</td>
      <td>Victor T. Na'Allah</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>7</td>
      <td>2</td>
      <td>Olajide Mattew</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>8</td>
      <td>3</td>
      <td>Abel Modu Timothy</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



### Create a  new column label and assign it accordingly


```python
new_col = list(dataset.loc[4])
new_col
```




    ['S/N', 'Name', 'Status', 'Amount Paid', 'T-shirt', nan, 'Comments']




```python
new_col[5] = 'T-Shirt Amount'
new_col
```




    ['S/N',
     'Name',
     'Status',
     'Amount Paid',
     'T-shirt',
     'T-Shirt Amount',
     'Comments']




```python
dataset.columns = new_col
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>S/N</th>
      <th>Name</th>
      <th>Status</th>
      <th>Amount Paid</th>
      <th>T-shirt</th>
      <th>T-Shirt Amount</th>
      <th>Comments</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>4</td>
      <td>S/N</td>
      <td>Name</td>
      <td>Status</td>
      <td>Amount Paid</td>
      <td>T-shirt</td>
      <td>NaN</td>
      <td>Comments</td>
    </tr>
    <tr>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Type</td>
      <td>Amount</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>6</td>
      <td>1</td>
      <td>Victor T. Na'Allah</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>7</td>
      <td>2</td>
      <td>Olajide Mattew</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>8</td>
      <td>3</td>
      <td>Abel Modu Timothy</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



### Create a new index label and assign it accordingly and


```python
new_index = list(dataset['Name'])
new_index
```




    ['Name',
     nan,
     "Victor T. Na'Allah",
     'Olajide Mattew',
     'Abel Modu Timothy',
     'Egwim Jones Udojuaku',
     'Nwachukwu Emmanuel Benedict',
     'Adole John A.',
     'Faleti Ayodeji Peter',
     'Ayantoye Ridwan Ayomide',
     'Marvellous  T. Isaac',
     'Shenge Raphael Saarshatar',
     'Reuben O.Enoch',
     'Mercy Ajayi',
     'Michael Kpoco',
     'Saad',
     'Terzungwe Caleb',
     'Faith',
     'Gonet Zion',
     'Hawwau Adeboyin Adeyemo\nFor => Jubrin Omeiza',
     'Nicholas Otonoku',
     'Timothy Ignitus Agbor',
     'Madumche Chidibere',
     'Nwokocha Ethelbert',
     'Effiong Ubon Alasi ',
     'Daniel Overcomer',
     'Aguwa Wisdom',
     'Ganiyu Mujeeb',
     'Hezekiel Joel',
     'Shitu Mustapha Ibrahim',
     'Orogu Francis Israel',
     'Agha Elizabeth',
     'Muhammed Zainab',
     'Isaac Priscilla',
     'Paul Elizabeth Ladi',
     'Omaji Samuel Owoicho',
     'Esinome Abraham',
     'Umeh Audu Ayigba',
     'Sarah Kauna Edoja',
     'Ibrahim Hussein Chado',
     'Fatima Ganiyu',
     'Daleng Elisha Nandi',
     'Ukande Aondongu Cephas',
     'De-Gold David Tarki',
     'Shekinah Ajibola',
     'Adanu David',
     'Oche Muscle',
     'Ocheje Jeremiah',
     'Oguntowo Basit Ifedolapo',
     'Simeon Iganga',
     'Caleb Onuoja Aaron',
     nan,
     nan]



### There are some " nan" in. the index list i just created. To avoid having issues dealing with them, I decided to give it a proper name below


```python
new_index[1] = "count"
```


```python
new_index[-1] = "total"
```


```python
new_index[-2] = "type"
```


```python
new_index
```




    ['Name',
     'count',
     "Victor T. Na'Allah",
     'Olajide Mattew',
     'Abel Modu Timothy',
     'Egwim Jones Udojuaku',
     'Nwachukwu Emmanuel Benedict',
     'Adole John A.',
     'Faleti Ayodeji Peter',
     'Ayantoye Ridwan Ayomide',
     'Marvellous  T. Isaac',
     'Shenge Raphael Saarshatar',
     'Reuben O.Enoch',
     'Mercy Ajayi',
     'Michael Kpoco',
     'Saad',
     'Terzungwe Caleb',
     'Faith',
     'Gonet Zion',
     'Hawwau Adeboyin Adeyemo\nFor => Jubrin Omeiza',
     'Nicholas Otonoku',
     'Timothy Ignitus Agbor',
     'Madumche Chidibere',
     'Nwokocha Ethelbert',
     'Effiong Ubon Alasi ',
     'Daniel Overcomer',
     'Aguwa Wisdom',
     'Ganiyu Mujeeb',
     'Hezekiel Joel',
     'Shitu Mustapha Ibrahim',
     'Orogu Francis Israel',
     'Agha Elizabeth',
     'Muhammed Zainab',
     'Isaac Priscilla',
     'Paul Elizabeth Ladi',
     'Omaji Samuel Owoicho',
     'Esinome Abraham',
     'Umeh Audu Ayigba',
     'Sarah Kauna Edoja',
     'Ibrahim Hussein Chado',
     'Fatima Ganiyu',
     'Daleng Elisha Nandi',
     'Ukande Aondongu Cephas',
     'De-Gold David Tarki',
     'Shekinah Ajibola',
     'Adanu David',
     'Oche Muscle',
     'Ocheje Jeremiah',
     'Oguntowo Basit Ifedolapo',
     'Simeon Iganga',
     'Caleb Onuoja Aaron',
     'type',
     'total']




```python
dataset.index = new_index
```


```python
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>S/N</th>
      <th>Name</th>
      <th>Status</th>
      <th>Amount Paid</th>
      <th>T-shirt</th>
      <th>T-Shirt Amount</th>
      <th>Comments</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Name</td>
      <td>S/N</td>
      <td>Name</td>
      <td>Status</td>
      <td>Amount Paid</td>
      <td>T-shirt</td>
      <td>NaN</td>
      <td>Comments</td>
    </tr>
    <tr>
      <td>count</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Type</td>
      <td>Amount</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Victor T. Na'Allah</td>
      <td>1</td>
      <td>Victor T. Na'Allah</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Olajide Mattew</td>
      <td>2</td>
      <td>Olajide Mattew</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Abel Modu Timothy</td>
      <td>3</td>
      <td>Abel Modu Timothy</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



### Now, delete the irrelevant rows and columns in the dataset at this stage.


```python
dataset.drop(['Name','count','type','total'], inplace = True)
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>S/N</th>
      <th>Name</th>
      <th>Status</th>
      <th>Amount Paid</th>
      <th>T-shirt</th>
      <th>T-Shirt Amount</th>
      <th>Comments</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Victor T. Na'Allah</td>
      <td>1</td>
      <td>Victor T. Na'Allah</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Olajide Mattew</td>
      <td>2</td>
      <td>Olajide Mattew</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Abel Modu Timothy</td>
      <td>3</td>
      <td>Abel Modu Timothy</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Egwim Jones Udojuaku</td>
      <td>4</td>
      <td>Egwim Jones Udojuaku</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Nwachukwu Emmanuel Benedict</td>
      <td>5</td>
      <td>Nwachukwu Emmanuel Benedict</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
dataset.drop(['S/N', 'Name', 'Comments'], axis = 1, inplace = True)

```


```python
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Status</th>
      <th>Amount Paid</th>
      <th>T-shirt</th>
      <th>T-Shirt Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Victor T. Na'Allah</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Olajide Mattew</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Abel Modu Timothy</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Egwim Jones Udojuaku</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Nwachukwu Emmanuel Benedict</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
  </tbody>
</table>
</div>




```python
dataset.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Status</th>
      <th>Amount Paid</th>
      <th>T-shirt</th>
      <th>T-Shirt Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>49</td>
      <td>48</td>
      <td>39</td>
      <td>39</td>
    </tr>
    <tr>
      <td>unique</td>
      <td>2</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <td>top</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>freq</td>
      <td>44</td>
      <td>38</td>
      <td>18</td>
      <td>18</td>
    </tr>
  </tbody>
</table>
</div>



###  Now, it's time to deal with the null data in this dataset. If you decide to drop the null values at this stage, you'll be losing a large chunk of valuable data. A better alternative is to fill the null values as the case requires. My approach is written below


```python
dataset["Amount Paid"].fillna(0, inplace = True)
```


```python
dataset.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 49 entries, Victor T. Na'Allah to Caleb Onuoja Aaron
    Data columns (total 4 columns):
    Status            49 non-null object
    Amount Paid       49 non-null int64
    T-shirt           39 non-null object
    T-Shirt Amount    39 non-null object
    dtypes: int64(1), object(3)
    memory usage: 1.1+ KB



```python
dataset["T-shirt"].fillna("Long Sleeve", inplace = True)
```


```python
dataset["T-Shirt Amount"].fillna(2500, inplace = True)
```


```python
dataset["T-shirt"].replace({"NIL":"No Sleeve"}, inplace = True)
```


```python
dataset["T-Shirt Amount"].replace({"NIL":0}, inplace = True)
```


```python
dataset.index.name = "Name"
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Status</th>
      <th>Amount Paid</th>
      <th>T-shirt</th>
      <th>T-Shirt Amount</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Victor T. Na'Allah</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Olajide Mattew</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Abel Modu Timothy</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Egwim Jones Udojuaku</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Nwachukwu Emmanuel Benedict</td>
      <td>Member</td>
      <td>12000</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
  </tbody>
</table>
</div>



### Here, i realized the "Shirt Amount" column is an integer but it's not assigned the correct data type. Hence, i manipulated it to bring it back to the right data type. Just understand the tools at your disposal and the task you want to execute. You can always get creative about how to go about it


```python
shortamount = np.array(dataset["T-Shirt Amount"], dtype = np.int64)
shortamount
```




    array([2500, 2500, 2500, 2500, 2500, 2100, 2100, 2500, 2100, 2100, 2500,
           2500, 2100, 2500, 2100, 2500, 2500, 2500, 2100, 2500, 2500, 2100,
           2500, 2100, 2500, 2500, 2500, 2500, 2100, 2100, 2500, 2100, 2100,
           2100, 2100, 2100, 2500,    0,    0, 2500, 2500, 2500, 2500,    0,
              0, 2100, 2500, 2500, 2500], dtype=int64)




```python
dataset["T-Shirt Amount"] = shortamount
dataset["T-Shirt Amount"].head(20)
```




    Name
    Victor T. Na'Allah                               2500
    Olajide Mattew                                   2500
    Abel Modu Timothy                                2500
    Egwim Jones Udojuaku                             2500
    Nwachukwu Emmanuel Benedict                      2500
    Adole John A.                                    2100
    Faleti Ayodeji Peter                             2100
    Ayantoye Ridwan Ayomide                          2500
    Marvellous  T. Isaac                             2100
    Shenge Raphael Saarshatar                        2100
    Reuben O.Enoch                                   2500
    Mercy Ajayi                                      2500
    Michael Kpoco                                    2100
    Saad                                             2500
    Terzungwe Caleb                                  2100
    Faith                                            2500
    Gonet Zion                                       2500
    Hawwau Adeboyin Adeyemo\nFor => Jubrin Omeiza    2500
    Nicholas Otonoku                                 2100
    Timothy Ignitus Agbor                            2500
    Name: T-Shirt Amount, dtype: int64



### The dataset is clean and ready for further analysis a d exploration to derive deep insights.

###   But wait a minute, remember i mentioned the Dataset you'll be dealing with is 2 contained in the same file. You'll read the second file now, clean and merge it with the first one you've worked on

### The second dataset has been imported and read. Notice that in the line of code used to import the file, "sheet_name" was set to 1. So it read the second sheet of the source file. When it's not included, that means it's on it's defaults that's set to 0. And automatically reads the first page of the source file


```python
dataset1 = pd.read_excel("Excursion Portfolio.xls", sheet_name = 1)
dataset1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Unnamed: 1</th>
      <th>Unnamed: 2</th>
      <th>Unnamed: 3</th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>S/N</td>
      <td>Name</td>
      <td>Type</td>
      <td>T-shirt</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Type</td>
      <td>Amount</td>
    </tr>
    <tr>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>Abuh E. Rasheed</td>
      <td>Exco</td>
      <td>Short Sleeve</td>
      <td>2100</td>
    </tr>
    <tr>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2</td>
      <td>Didi Chukwuebuka V.</td>
      <td>Exco</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
  </tbody>
</table>
</div>



### Drop the rows and columns of the dataset that contains "nan" all true


```python
dataset1.dropna(how = 'all', inplace = True)
```


```python
dataset1.dropna(how = 'all', axis = 1, inplace = True)
```


```python
dataset1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>S/N</td>
      <td>Name</td>
      <td>Type</td>
      <td>T-shirt</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Type</td>
      <td>Amount</td>
    </tr>
    <tr>
      <td>3</td>
      <td>1</td>
      <td>Abuh E. Rasheed</td>
      <td>Exco</td>
      <td>Short Sleeve</td>
      <td>2100</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2</td>
      <td>Didi Chukwuebuka V.</td>
      <td>Exco</td>
      <td>Long Sleeve</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>5</td>
      <td>3</td>
      <td>Jonathan Ajiboye</td>
      <td>Exco</td>
      <td>Short Sleeve</td>
      <td>2100</td>
    </tr>
  </tbody>
</table>
</div>



### Next, give your index label and column label appropriate names to make them more relatable.

### Then drop the irrelevant rows and columsns respectively


```python
new_col1 = list(dataset1.loc[1])
new_col1
```




    ['S/N', 'Name', 'Type', 'T-shirt', nan]




```python
new_col1[2] = "Status"
new_col1[-1] = "T-Shirt Amount"
new_col1
```




    ['S/N', 'Name', 'Status', 'T-shirt', 'T-Shirt Amount']




```python
dataset1.columns = new_col1
```


```python
dataset1.drop([1,2,16,17,27], inplace = True)
```


```python
dataset1.index = dataset1.Name
```


```python
dataset1.drop("Name", axis =1, inplace = True)
```


```python
dataset1.drop("S/N", axis = 1, inplace = True)
```

### This first Dataset has a column called "Amount Paid", but that column is absent in the secomd dataset. Hence i created a new column in the second Dataset with the same name and values of zero all true.


### I used the numpy zeros function to create the array and used that to create the required in the second Dataset.

### Like i mentioned earlier on, just know your tools and understand the task you want to execute. There's no limitation to unleashing your creativity


```python
new_array = np.zeros((13,1), dtype = np.int64)
new_array
```




    array([[0],
           [0],
           [0],
           [0],
           [0],
           [0],
           [0],
           [0],
           [0],
           [0],
           [0],
           [0],
           [0]], dtype=int64)




```python
dataset1["Amount Paid"] = new_array
dataset1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Status</th>
      <th>T-shirt</th>
      <th>T-Shirt Amount</th>
      <th>Amount Paid</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Abuh E. Rasheed</td>
      <td>Exco</td>
      <td>Short Sleeve</td>
      <td>2100</td>
      <td>0</td>
    </tr>
    <tr>
      <td>Didi Chukwuebuka V.</td>
      <td>Exco</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>0</td>
    </tr>
    <tr>
      <td>Jonathan Ajiboye</td>
      <td>Exco</td>
      <td>Short Sleeve</td>
      <td>2100</td>
      <td>0</td>
    </tr>
    <tr>
      <td>Yusuff Fatorisa</td>
      <td>Exco</td>
      <td>Short Sleeve</td>
      <td>2100</td>
      <td>0</td>
    </tr>
    <tr>
      <td>Gabriel Alkali</td>
      <td>Exco</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



### Like the first dataset, the "Shirt _Amount" column consist of integers but have the wrong data type. So i manipulated it bring it back to the right data type


```python
shortamount1 = np.array(dataset1["T-Shirt Amount"], dtype = np.int64)
shortamount1
```




    array([2100, 2500, 2100, 2100, 2500, 2100, 2500, 2100, 2500, 2500, 2500,
           2500, 2500], dtype=int64)




```python
dataset1["T-Shirt Amount"] = shortamount1
dataset1["T-Shirt Amount"]
```




    Name
    Abuh E. Rasheed         2100
    Didi Chukwuebuka V.     2500
    Jonathan Ajiboye        2100
    Yusuff Fatorisa         2100
    Gabriel Alkali          2500
    Ebube Onuigbo           2100
    Sanusi Muhammad         2500
    Ameh Sunday             2100
    Bawa Vincent            2500
    Bala Monday             2500
    Mukaila Abdul-Rafiu     2500
    Cynthia John            2500
    Victor Chumnon          2500
    Name: T-Shirt Amount, dtype: int64




```python
dataset1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 13 entries, Abuh E. Rasheed to Victor Chumnon
    Data columns (total 4 columns):
    Status            13 non-null object
    T-shirt           13 non-null object
    T-Shirt Amount    13 non-null int64
    Amount Paid       13 non-null int64
    dtypes: int64(2), object(2)
    memory usage: 748.0+ bytes



```python
recol = ["Status", "Amount Paid", "T-shirt", "T-Shirt Amount"]
recol
```




    ['Status', 'Amount Paid', 'T-shirt', 'T-Shirt Amount']




```python
dataset1.reindex(columns = recol)
dataset1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Status</th>
      <th>T-shirt</th>
      <th>T-Shirt Amount</th>
      <th>Amount Paid</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Abuh E. Rasheed</td>
      <td>Exco</td>
      <td>Short Sleeve</td>
      <td>2100</td>
      <td>0</td>
    </tr>
    <tr>
      <td>Didi Chukwuebuka V.</td>
      <td>Exco</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>0</td>
    </tr>
    <tr>
      <td>Jonathan Ajiboye</td>
      <td>Exco</td>
      <td>Short Sleeve</td>
      <td>2100</td>
      <td>0</td>
    </tr>
    <tr>
      <td>Yusuff Fatorisa</td>
      <td>Exco</td>
      <td>Short Sleeve</td>
      <td>2100</td>
      <td>0</td>
    </tr>
    <tr>
      <td>Gabriel Alkali</td>
      <td>Exco</td>
      <td>Long Sleeve</td>
      <td>2500</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



### Both dataset are clean and ready. So use concat function to merge them together

### i also rewrite it back into an excel file.

## Now it's time for 

# "DATA VISUALIZATION"


```python
comb_dataset = pd.concat([dataset,dataset1])
comb_dataset.tail()
```

    /data/user/0/ru.iiec.pydroid3/files/arm-linux-androideabi/lib/python3.7/site-packages/ipykernel_launcher.py:1: FutureWarning: Sorting because non-concatenation axis is not aligned. A future version
    of pandas will change to not sort by default.
    
    To accept the future behavior, pass 'sort=False'.
    
    To retain the current behavior and silence the warning, pass 'sort=True'.
    
      """Entry point for launching an IPython kernel.





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Amount Paid</th>
      <th>Status</th>
      <th>T-Shirt Amount</th>
      <th>T-shirt</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Bawa Vincent</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Bala Monday</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Mukaila Abdul-Rafiu</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Cynthia John</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Victor Chumnon</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
  </tbody>
</table>
</div>




```python
comb_dataset.to_excel("ExcurPort.xlsx")
```

### I made use of the "groupby" fuction to extract the required data and plot the Visualization


```python
class1 = comb_dataset["Amount Paid"].groupby(comb_dataset["Status"])
class11 = class1.count()
class11
crass = list(class11.index)
crass
```




    ['Ex-Exco', 'Exco', 'Member']




```python
plt.bar(crass,class11)
plt.title("Participants Bar-Chart")
plt.xlabel("Participant's Status")
plt.ylabel("Frequency")
plt.savefig("F-Dset.png")
```


![png](output_74_0.png)



```python
plt.pie(class11, labels = crass, startangle = 265, autopct ="%1.2f%%")
plt.title("Participant's Pie-Chart")
plt.savefig("F-Dset1.png")
plt.show()
```


![png](output_75_0.png)



```python
class4 = comb_dataset["T-Shirt Amount"].groupby(comb_dataset["T-shirt"])
class4.unique()
class41 = class4.count()
crass41 = list(class41.index)
crass41
```




    ['Long Sleeve', 'No Sleeve', 'Short Sleeve']




```python
plt.bar(crass41, class41)
plt.title("T-Shirt Request & Choices", fontstyle = 'normal')
plt.xlabel("T-Shirt Types", alpha = 0.7, fontstyle = 'italic')
plt.ylabel("Frequency", alpha = 0.7, fontstyle = 'italic')
plt.savefig("F-Dset3.png")
```


![png](output_77_0.png)



```python
plt.pie(class41, labels = crass41, autopct ="%1.2d%%", startangle = 30)
plt.title("T-Shirt Request Chart")
plt.savefig("F-Dset4.png")
```


![png](output_78_0.png)



```python
parts = [0,0.9,8001,12001]
parts_label = ("Excos","Ex-Excos","Member")
```


```python
class2 = pd.cut(comb_dataset["Amount Paid"], parts, labels = parts_label, right = False)
class21 = pd.value_counts(class2)
class21
```




    Member      42
    Excos       14
    Ex-Excos     6
    Name: Amount Paid, dtype: int64




```python
class21.plot(kind = 'bar')
plt.title("Categories Of Excursion Participants")
plt.xlabel("Categories")
plt.ylabel("Frequency")
plt.savefig("F-Dset5.png")
```


![png](output_81_0.png)



```python
class21.plot(kind = "pie", autopct ="%1.2d%%", startangle = 0)
plt.ylabel('')
plt.title("Excursion Participants",alpha = 0.85)
plt.savefig("F-Dset6.png")
```


![png](output_82_0.png)



```python
tparts = [0,5,2101,2501]
tparts_label = ("No Sleeve","Short Sleeve", "Long Sleeve")
```


```python
class3 = pd.cut(comb_dataset["T-Shirt Amount"],tparts, labels = tparts_label, right = False)
class31 = pd.value_counts(class3)
class31
```




    Long Sleeve     36
    Short Sleeve    22
    No Sleeve        4
    Name: T-Shirt Amount, dtype: int64




```python
class31.plot(kind = "bar")
plt.title("T-Shirts Requests & Choices")
plt.xlabel("T-Shirts Types")
plt.ylabel("Requests Frequency")
plt.savefig("F-Dset7.png")
```


![png](output_85_0.png)



```python
class31.plot(kind = "pie", startangle = 90, autopct = '%1.2d%%', label = ("LONG","SHORT"))
plt.ylabel("")
plt.title("T-Shirt Requests", alpha = 0.85)
plt.savefig("F-Dset8.png")
```


![png](output_86_0.png)


### There's still a whole bunch of amazing things you can do using the "Matplotlib Library". But I'll leave you to do more exploration and discoveries on your own


```python
comb_dataset["Status"].unique()
```




    array(['Member', 'Ex-Exco', 'Exco'], dtype=object)




```python
comb_dataset["T-shirt"].unique()
```




    array(['Long Sleeve', 'Short Sleeve', 'No Sleeve'], dtype=object)




```python
comb_dataset["T-Shirt Amount"].unique()
```




    array([2500, 2100,    0], dtype=int64)




```python
comb_dataset["Amount Paid"].unique()
```




    array([12000,  7000,  5000,  8000, 10000,     0,  9000,  9500],
          dtype=int64)




```python
comb_dataset[comb_dataset["Amount Paid"] == 12000]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Amount Paid</th>
      <th>Status</th>
      <th>T-Shirt Amount</th>
      <th>T-shirt</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Victor T. Na'Allah</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Olajide Mattew</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Abel Modu Timothy</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Egwim Jones Udojuaku</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Nwachukwu Emmanuel Benedict</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Adole John A.</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Faleti Ayodeji Peter</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Ayantoye Ridwan Ayomide</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Marvellous  T. Isaac</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Shenge Raphael Saarshatar</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Reuben O.Enoch</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Mercy Ajayi</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Saad</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Faith</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Gonet Zion</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Hawwau Adeboyin Adeyemo\nFor =&gt; Jubrin Omeiza</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Nicholas Otonoku</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Timothy Ignitus Agbor</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Madumche Chidibere</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Effiong Ubon Alasi</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Daniel Overcomer</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Aguwa Wisdom</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Ganiyu Mujeeb</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Hezekiel Joel</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Shitu Mustapha Ibrahim</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Orogu Francis Israel</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Agha Elizabeth</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Muhammed Zainab</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Isaac Priscilla</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Paul Elizabeth Ladi</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Esinome Abraham</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Umeh Audu Ayigba</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Ukande Aondongu Cephas</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>De-Gold David Tarki</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Shekinah Ajibola</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Ocheje Jeremiah</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Oguntowo Basit Ifedolapo</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Simeon Iganga</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
  </tbody>
</table>
</div>




```python
comb_dataset[comb_dataset["Amount Paid"] == 8000]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Amount Paid</th>
      <th>Status</th>
      <th>T-Shirt Amount</th>
      <th>T-shirt</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Nwokocha Ethelbert</td>
      <td>8000</td>
      <td>Ex-Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Omaji Samuel Owoicho</td>
      <td>8000</td>
      <td>Ex-Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Sarah Kauna Edoja</td>
      <td>8000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Caleb Onuoja Aaron</td>
      <td>8000</td>
      <td>Ex-Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
  </tbody>
</table>
</div>




```python
comb_dataset[comb_dataset["Amount Paid"] < 12000]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Amount Paid</th>
      <th>Status</th>
      <th>T-Shirt Amount</th>
      <th>T-shirt</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Michael Kpoco</td>
      <td>7000</td>
      <td>Ex-Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Terzungwe Caleb</td>
      <td>5000</td>
      <td>Ex-Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Nwokocha Ethelbert</td>
      <td>8000</td>
      <td>Ex-Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Omaji Samuel Owoicho</td>
      <td>8000</td>
      <td>Ex-Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Sarah Kauna Edoja</td>
      <td>8000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Ibrahim Hussein Chado</td>
      <td>10000</td>
      <td>Member</td>
      <td>0</td>
      <td>No Sleeve</td>
    </tr>
    <tr>
      <td>Fatima Ganiyu</td>
      <td>0</td>
      <td>Member</td>
      <td>0</td>
      <td>No Sleeve</td>
    </tr>
    <tr>
      <td>Daleng Elisha Nandi</td>
      <td>9000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Adanu David</td>
      <td>9000</td>
      <td>Member</td>
      <td>0</td>
      <td>No Sleeve</td>
    </tr>
    <tr>
      <td>Oche Muscle</td>
      <td>9500</td>
      <td>Member</td>
      <td>0</td>
      <td>No Sleeve</td>
    </tr>
    <tr>
      <td>Caleb Onuoja Aaron</td>
      <td>8000</td>
      <td>Ex-Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Abuh E. Rasheed</td>
      <td>0</td>
      <td>Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Didi Chukwuebuka V.</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Jonathan Ajiboye</td>
      <td>0</td>
      <td>Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Yusuff Fatorisa</td>
      <td>0</td>
      <td>Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Gabriel Alkali</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Ebube Onuigbo</td>
      <td>0</td>
      <td>Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Sanusi Muhammad</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Ameh Sunday</td>
      <td>0</td>
      <td>Exco</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Bawa Vincent</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Bala Monday</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Mukaila Abdul-Rafiu</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Cynthia John</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Victor Chumnon</td>
      <td>0</td>
      <td>Exco</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
  </tbody>
</table>
</div>




```python
comb_dataset[comb_dataset["Status"] == "Member"]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Amount Paid</th>
      <th>Status</th>
      <th>T-Shirt Amount</th>
      <th>T-shirt</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Victor T. Na'Allah</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Olajide Mattew</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Abel Modu Timothy</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Egwim Jones Udojuaku</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Nwachukwu Emmanuel Benedict</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Adole John A.</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Faleti Ayodeji Peter</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Ayantoye Ridwan Ayomide</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Marvellous  T. Isaac</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Shenge Raphael Saarshatar</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Reuben O.Enoch</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Mercy Ajayi</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Saad</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Faith</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Gonet Zion</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Hawwau Adeboyin Adeyemo\nFor =&gt; Jubrin Omeiza</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Nicholas Otonoku</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Timothy Ignitus Agbor</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Madumche Chidibere</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Effiong Ubon Alasi</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Daniel Overcomer</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Aguwa Wisdom</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Ganiyu Mujeeb</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Hezekiel Joel</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Shitu Mustapha Ibrahim</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Orogu Francis Israel</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Agha Elizabeth</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Muhammed Zainab</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Isaac Priscilla</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Paul Elizabeth Ladi</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Esinome Abraham</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Umeh Audu Ayigba</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Sarah Kauna Edoja</td>
      <td>8000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Ibrahim Hussein Chado</td>
      <td>10000</td>
      <td>Member</td>
      <td>0</td>
      <td>No Sleeve</td>
    </tr>
    <tr>
      <td>Fatima Ganiyu</td>
      <td>0</td>
      <td>Member</td>
      <td>0</td>
      <td>No Sleeve</td>
    </tr>
    <tr>
      <td>Daleng Elisha Nandi</td>
      <td>9000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Ukande Aondongu Cephas</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>De-Gold David Tarki</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Shekinah Ajibola</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Adanu David</td>
      <td>9000</td>
      <td>Member</td>
      <td>0</td>
      <td>No Sleeve</td>
    </tr>
    <tr>
      <td>Oche Muscle</td>
      <td>9500</td>
      <td>Member</td>
      <td>0</td>
      <td>No Sleeve</td>
    </tr>
    <tr>
      <td>Ocheje Jeremiah</td>
      <td>12000</td>
      <td>Member</td>
      <td>2100</td>
      <td>Short Sleeve</td>
    </tr>
    <tr>
      <td>Oguntowo Basit Ifedolapo</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Simeon Iganga</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
  </tbody>
</table>
</div>




```python
extract = comb_dataset[comb_dataset.Status == "Member"]
extract.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Amount Paid</th>
      <th>Status</th>
      <th>T-Shirt Amount</th>
      <th>T-shirt</th>
    </tr>
    <tr>
      <th>Name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Victor T. Na'Allah</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Olajide Mattew</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Abel Modu Timothy</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Egwim Jones Udojuaku</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>Nwachukwu Emmanuel Benedict</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
  </tbody>
</table>
</div>



### Try using the "set_index()" and "reset_index()" methods and have a feel of advanced techniques of data manipulation


```python
extract1 = extract.reset_index()
extract1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Amount Paid</th>
      <th>Status</th>
      <th>T-Shirt Amount</th>
      <th>T-shirt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>Victor T. Na'Allah</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>1</td>
      <td>Olajide Mattew</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Abel Modu Timothy</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Egwim Jones Udojuaku</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Nwachukwu Emmanuel Benedict</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
      <td>Long Sleeve</td>
    </tr>
  </tbody>
</table>
</div>




```python
extract11 = extract1.set_index(["Name","T-shirt"])
extract11.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Amount Paid</th>
      <th>Status</th>
      <th>T-Shirt Amount</th>
    </tr>
    <tr>
      <th>Name</th>
      <th>T-shirt</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Victor T. Na'Allah</td>
      <td>Long Sleeve</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Olajide Mattew</td>
      <td>Long Sleeve</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Abel Modu Timothy</td>
      <td>Long Sleeve</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Egwim Jones Udojuaku</td>
      <td>Long Sleeve</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
    </tr>
    <tr>
      <td>Nwachukwu Emmanuel Benedict</td>
      <td>Long Sleeve</td>
      <td>12000</td>
      <td>Member</td>
      <td>2500</td>
    </tr>
  </tbody>
</table>
</div>



### This are just a few of the exciting and amazing this the Python libraries can do to help you achieve your designated tasks. 

### Remember, the best way to learn is by doing, so

# Practice ! Practice !! Practice !!!

### I wish you a beautiful ride on this exciting journey.

# Happy Learning


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
